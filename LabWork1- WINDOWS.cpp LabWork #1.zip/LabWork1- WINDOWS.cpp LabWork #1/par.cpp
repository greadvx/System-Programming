#include<Windows.h>
#include<stdio.h>
#include<conio.h>
#include<time.h>
#include<iostream>
void main(VOID)
{
	Sleep(1000);
	printf("Hello, mr. User. I'm a parent :)\n");
	Sleep(2000);
	time_t realT;
	
	STARTUPINFO Startupinfo;
	PROCESS_INFORMATION ProcInf;
	TCHAR CommandLine[]=TEXT("happy.exe");
	ZeroMemory(&Startupinfo, sizeof(Startupinfo));
	Startupinfo.cb = sizeof(Startupinfo);
	ZeroMemory(&ProcInf, sizeof(ProcInf));
	time(&realT);
	std::cout << "start: "<<ctime(&realT)<<std::endl;
	if (!CreateProcess(NULL, CommandLine, NULL, NULL, FALSE, 0, NULL, NULL, &Startupinfo, &ProcInf)) printf("Create proc failed\n");
	
	WaitForSingleObject(ProcInf.hProcess, INFINITE);

	time(&realT);
	std::cout << "finish: " << ctime(&realT) << std::endl;

	CloseHandle(ProcInf.hProcess);
	CloseHandle(ProcInf.hThread);

	getch();
}