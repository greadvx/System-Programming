#include<Windows.h>
#include<stdio.h>
#include<iostream>
#include<time.h>
void main(VOID)
{
	time_t realT;
	time(&realT);
	std::cout << "start: " << ctime(&realT) << std::endl;
	int ms[32];
	printf("Hello, your array\n");
	for (int i = 0; i < 32; i++)
	{
		ms[i] = rand() % 100;
		printf("%d ", ms[i]);
	}
		
	int max=ms[0], min =max;
	for (int i = 1; i < 32; i++)
	{
		if (ms[i]>max)
		{
			max = ms[i];
		}
		if (ms[i] < min)
		{
			min = ms[i];
		}
	}
	printf("\nMAX=%d\nMIN=%d\n", max, min);
	time(&realT);
	std::cout << "\nfinish: " << ctime(&realT) << std::endl;
	Sleep(1000);

	return;
}